-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 29, 2021 at 09:58 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `housing`
--

-- --------------------------------------------------------

--
-- Table structure for table `cmps`
--

DROP TABLE IF EXISTS `cmps`;
CREATE TABLE IF NOT EXISTS `cmps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `cmp` varchar(200) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cmps`
--

INSERT INTO `cmps` (`id`, `name`, `cmp`, `username`, `fullname`) VALUES
(5, 'talent', 'The system is too slow', 'Tally', 'Talent'),
(2, 'Rejoice Kaunda', 'The system is too slow', 'Jojoe', 'Rejoice Kaunda'),
(3, 'Comfort', 'The system is too slow', 'Comfy', 'Comfort Ndirwenyu'),
(4, 'nkosana', 'The system is too slow', 'nkossy', 'nkosana dube');

-- --------------------------------------------------------

--
-- Table structure for table `room_rental_registrations`
--

DROP TABLE IF EXISTS `room_rental_registrations`;
CREATE TABLE IF NOT EXISTS `room_rental_registrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternat_mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deposit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plot_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rooms` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accommodation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_for_sharing` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacant` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_rental_registrations_mobile_unique` (`mobile`),
  UNIQUE KEY `room_rental_registrations_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_rental_registrations`
--

INSERT INTO `room_rental_registrations` (`id`, `fullname`, `mobile`, `alternat_mobile`, `email`, `country`, `state`, `city`, `landmark`, `rent`, `sale`, `deposit`, `plot_number`, `rooms`, `address`, `accommodation`, `description`, `image`, `open_for_sharing`, `other`, `vacant`, `created_at`, `updated_at`, `user_id`) VALUES
(19, 'nkosana dube', '0712872127', '', 'mercy@gmail.com', '', '', '', '', '$60', NULL, '$30', '', NULL, 'No 6 Impala Rd', '', 'wifi, security, clean water', 'uploads/CoC3.jpg', NULL, NULL, 1, '2021-08-01 21:26:32', '2021-08-01 21:26:32', 10),
(18, 'Comfort Ndirwenyu', '0772575632', '', 'comfy@gmail.com', '', '', '', '', '$60', NULL, '$30', '', NULL, 'No 6 Impala Rd', '', 'wifi, security, clean water', 'uploads/CoC3.jpg', NULL, NULL, 1, '2021-08-01 21:12:43', '2021-08-01 21:12:43', 9),
(17, 'Rejoice Kaunda', '0779876321', '', 'rejoicekaunda@gmail.com', '', '', '', '', '$60', NULL, '$30', '', NULL, '3827 Emganwini', '', 'wifi, security, clean water', 'uploads/images (3).jfif', NULL, NULL, 1, '2021-07-31 16:34:47', '2021-07-31 16:34:47', 8),
(16, 'John Dube', '0777958155', '', 'mohankossie@gmail.com', '', '', '', '', '$60', NULL, '$30', '', NULL, '3827 Emganwini', '', 'Large yard, free wifi, solar geysers', 'uploads/Annotation 2020-12-26 204143.jpg', NULL, NULL, 1, '2021-07-30 09:40:37', '2021-07-30 09:40:37', 7),
(20, 'Talent', '0716871127', '', 'tally@gmail.com', '', '', '', '', '$60', NULL, '$30', '', NULL, 'No 6 Impala Rd', '', 'wifi, security, clean water', 'uploads/CoC3.jpg', NULL, NULL, 1, '2021-08-01 21:34:21', '2021-08-01 21:34:21', 11);

-- --------------------------------------------------------

--
-- Table structure for table `room_rental_registrations_apartment`
--

DROP TABLE IF EXISTS `room_rental_registrations_apartment`;
CREATE TABLE IF NOT EXISTS `room_rental_registrations_apartment` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternat_mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deposit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plot_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apartment_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ap_number_of_plats` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rooms` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `own` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accommodation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_for_sharing` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacant` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_mobile_unique` (`mobile`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `mobile`, `username`, `email`, `password`, `created_at`, `updated_at`, `role`, `status`) VALUES
(1, 'George Kaunda', '0782108681', 'admin', 'george@gkay.co.zw', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, 'admin', 1),
(8, 'Rejoice Kaunda', '0777958155', 'Jojoe', 'rejoicekaunda@gmail.com', '6df188b71685bd9abfb321e158478afd', '2021-07-31 16:21:36', '2021-07-31 16:21:36', 'user', 1),
(7, 'John Dube', '0777958154', 'Johnny', 'mohankossie@gmail.com', '9e04eee4678cfae89f4e9038f58c89f1', '2021-07-30 09:28:42', '2021-07-30 09:28:42', 'user', 1),
(9, 'Comfort Ndirwenyu', '0776524352', 'Comfy', 'comfy@gmail.com', '30184df773512b38104d97ca0fccb648', '2021-08-01 21:11:01', '2021-08-01 21:11:01', 'user', 1),
(10, 'nkosana dube', '0712871127', 'nkossy', 'mercy@gmail.com', '0bf52c6e99a5cfc54e54e439bf7df2b5', '2021-08-01 21:25:48', '2021-08-01 21:25:48', 'user', 1),
(11, 'Talent', '0716871127', 'Tally', 'tally@gmail.com', '9ec7fab24630e09ef1528e905838d4ff', '2021-08-01 21:33:37', '2021-08-01 21:33:37', 'user', 1),
(12, 'Mbalenhle', '0784768556', 'Mbalie', 'mbalie@gmail.com', '77c8ddb27a22d5de0135368bb8e19213', '2021-08-26 21:22:26', '2021-08-26 21:22:26', 'user', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
