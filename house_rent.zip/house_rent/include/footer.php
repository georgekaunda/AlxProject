    <!-- Bootstrap core JavaScript -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../assets/plugins/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="../assets/js/jqBootstrapValidation.js"></script>
    <script src="../assets/js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="../assets/js/rent.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){

        <?php
        $b_count = 50;
        for ($i=0; $i < $b_count; $i++) { 
        
          echo '
            $(document).on("click","#paynow_js'.$i.'", function(event){
                event.preventDefault();
                var email = $("#exampleFormControlInput'.$i.'").val();
                //check email
                var oldUrl = $("#paynow_js'.$i.'").attr("href");
                var newUrl = oldUrl+email;
                window.location.href = newUrl;
            });';
        }

        ?>

        //end of ready
      });
    </script>
  </body>
</html>
